% Funció per caclular la accuracy donats els w* i els sets x i y
function [acc] = accuracy(p,n,x,y,w)
    acc = 0;
    j = 1;
    while j<=p
        aux = 0;
        i = 1;
        while i<=n
           aux = aux + w(i)*(1+exp(-x(i,j)))^-1;
           i = i + 1; 
        end
        y_model = round((1+exp(-aux))^-1);
        delta = 0;
        if y_model == y(j), delta = 1;
        end
        acc = acc + delta;
        j = j + 1;
    end
    acc = acc * 100/p;
end