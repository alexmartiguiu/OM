clear;    
num_target=[8];
tr_freq= .5;
tr_p= 250;
te_q= 250;
tr_seed    = 1712;   
te_seed    = 2883;   

uo_nn_batch(tr_seed,te_seed);



