function [x_ultima_iter,f_ultima_iter,niter] = om_uo_solve_practica(x,Xtr,ytr,la,epsG,kmax,ils,ialmax,kmaxBLS,epsal,c1,c2,isd,isg_m,isg_al0,isg_k,icg,irc,nu,p);
    
    % Definim les funcions
    sig = @(Xtr) 1./(1+exp(-Xtr));
    y = @(Xtr,x) sig(x'*sig(Xtr)); 
    f = @(x) norm(y(Xtr,x)-ytr)^2 + (la*norm(x)^2)/2; % = L
    g = @(x) 2*sig(Xtr)*((y(Xtr,x)-ytr).*y(Xtr,x).*(1-y(Xtr,x)))'+la*x; % gL
    g_s = @(x,Xtr_s,ytr_s) 2*sig(Xtr_s)*((y(Xtr_s,x)-ytr_s).*y(Xtr_s,x).*(1-y(Xtr_s,x)))'+la*x; % = gL    
    
    % Inicialitzar vectors posant zeros.
    xk = zeros(length(x),kmax+1);
    dk = zeros(length(x),kmax+1);
    alk = zeros(1,kmax+1); 
    iWk = zeros(1,kmax+1);
    
    n = length(x);
    xk(:,1) = x;
    Hk = eye(n);
    k=1;
    k_sg = floor(isg_k*kmax); % agafa part entera
    al_sg = 0.01 * isg_al0;
    m = floor(isg_m*p);
    
    if isd ~= 7
        gx = g(xk(:,1));
    else % Crear minibatch
        batch = randi(p, 1, m);
        Xtr_s = Xtr(:, batch); ytr_s = ytr(batch);
        gx = g_s(xk(:,1),Xtr_s,ytr_s);
    end;
    
    while norm(gx) > epsG && k < kmax
        % Trobar la d
        [dk(:,k)] = descent_direction_practica(xk, gx, Hk, isd, icg, irc, nu, dk, k,m);
        
        % Trobar la alfa
        if isd ~= 7
            if k==1, almax = 1;
            elseif ialmax == 1, almax = alk(:,k-1)*(g_antic'*dk(:,k-1))/(gx'*dk(:,k));
            elseif ialmax == 2, almax = 2*(f(xk(:,k))-f(xk(:,k-1)))/(gx'*dk(:,k));
            end;
            [alk(1,k),iWk(1,k)] = uo_BLSNW32(f,g,xk(:,k),dk(:,k),almax,c1,c2,kmaxBLS,epsal);
        else % isd == 7
            if k <= k_sg, alk(1,k) = (1-k/k_sg)*isg_al0 + (k/k_sg)*al_sg;
            else, alk(1,k) = al_sg;
            end;
        end;
            
        % Trobar la x seguent
        xk(:,k+1) = xk(:,k)+alk(:,k)*dk(:,k);
        
        % Update els gradients
        g_antic = gx;
        if isd ~= 7
            gx = g(xk(:,k+1));
        else
            batch = randi(p, 1, m);
            Xtr_s = Xtr(:, batch); ytr_s = ytr(batch);
            gx = g_s(xk(:,k+1),Xtr_s,ytr_s);
        end;
        
        % Trobar Hk pel mètode QNM
        if isd == 3
            s = xk(:,k+1)-xk(:,k);
            y = gx-g_antic;
            ro = 1/(y'*s);
            Hk=(eye(n)-ro*s*y')*Hk*(eye(n)-ro*y*s')+ro*s*s';
        end;
        
        % Actualitzar k
        k = k+1;
    end
    
    % Treure els zeros que sobren dels vectors
    xk = xk(:,1:k);
    dk = dk(:,1:k);
    alk = alk(1,1:k);
    iWk = iWk(1,1:k);
    
    % Valors a retornar
    niter = k;
    x_ultima_iter = xk(:,k);
    f_ultima_iter = f(x_ultima_iter);
    
end