function [d] = descent_direction_practica(xk, gx, H, isd, icg, irc, nu, dk, k,m)
    
    beta = 0;
    
    % GM
    if isd == 1 || (isd == 2 && k == 1), d = -gx;
    
    % CGM
    elseif isd == 2
        gprev = g(xk(:,k-1));
        
        % If first iteration or must restart betak = 0.
        if ~(irc == 1 && mod(k, length(xk(:, 1))) == 0) && ~(irc == 2 && abs(gx' * gprev / norm(gx)^2) >= nu)
            % Fletcher-Reeves
            if icg == 1, beta = norm(gx)^2 / norm(gprev)^2;
            % Polak-Ribière
            else, beta = gx' * (gx - gprev) / norm(gprev)^2;
            end
        end
        d = -gx + beta * dk(:, k - 1); % Computation descent direction
    
    % BFGS
    elseif isd == 3, d = -H * gx;
    % SGM
    elseif isd == 7, d = -gx;
    end;
end