function [Xtr,ytr,wo,fo,tr_acc,Xte,yte,te_acc,niter,tex]=uo_nn_solve(num_target, tr_freq,tr_seed,tr_p,te_seed,te_q,la,epsG,kmax,ils,ialmax,kmaxBLS,epsal,c1,c2,isd,isg_m,isg_al0,isg_k,icg,irc,nu,iheader)

    t1 = clock;
    % Generate the training dataset
    [Xtr,ytr] = uo_nn_dataset(tr_seed, tr_p, num_target, tr_freq);
    [n,p] = size(Xtr);

    % Minimize w
    w1 = zeros(n,1);
    [wo,fo,niter] = om_uo_solve_practica(w1,Xtr,ytr,la,epsG,kmax,ils,ialmax,kmaxBLS,epsal,c1,c2,isd,isg_m,isg_al0,isg_k,icg,irc,nu,tr_p);
    
    %uo_nn_Xyplot(Xtr,ytr,wo);
    
    % Training acuracy
    tr_acc = accuracy(p,n,Xtr,ytr,wo);
    
    % Generate the test dataset
    [Xte,yte] = uo_nn_dataset(te_seed, te_q, num_target, tr_freq);
    
    %uo_nn_Xyplot(Xte,yte,wo);
    
    % Test acuracy
    te_acc = accuracy(p,n,Xte,yte,wo);
    
    t2 = clock;
    tex = etime(t2,t1);
    
end